package com.assign5.assign5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assign5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
